import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-manager',
  templateUrl: './branch-manager.component.html',
  styleUrls: ['./branch-manager.component.scss']
})
export class BranchManagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

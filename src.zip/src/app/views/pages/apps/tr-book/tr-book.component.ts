import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataTable } from "simple-datatables";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tr-book',
  templateUrl: './tr-book.component.html',
  styleUrls: ['./tr-book.component.scss']
})
export class TRBookComponent  implements OnInit {

  constructor(private modalService: NgbModal) { }
  basicModalCloseResult: string = '';

  ngOnInit(): void {
    const dataTable = new DataTable("#dataTableExample12");
  }

  openBasicModal(content){
    this.modalService.open(content, {}).result.then((result) => {
      this.basicModalCloseResult = "Modal closed" + result
    }).catch((res) => {});
  }
}
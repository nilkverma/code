import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataTable } from "simple-datatables";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-advisor-registration',
  templateUrl: './advisor-registration.component.html',
  styleUrls: ['./advisor-registration.component.scss']
})
export class AdvisorRegistrationComponent  implements OnInit {

  constructor(private modalService: NgbModal) { }
  basicModalCloseResult: string = '';

  ngOnInit(): void {
    const dataTable = new DataTable("#dataTableExample7");
  }

  openXlModal(content) {
    this.modalService.open(content, {size: 'xl'}).result.then((result) => {
      console.log("Modal closed" + result);
    }).catch((res) => {});
  }
}
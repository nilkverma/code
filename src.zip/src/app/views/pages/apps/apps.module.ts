import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { FullCalendarModule } from '@fullcalendar/angular'; // for FullCalendar!
import { NgbDropdownModule, NgbTooltipModule, NgbNavModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { SimplemdeModule, SIMPLEMDE_CONFIG } from 'ng2-simplemde'

import { AppsComponent } from './apps.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { BranchComponent } from './branch/branch.component';
import { RelationshipManagerComponent } from './employee/relationship-manager/relationship-manager.component';
import { StaffRegistrationComponent } from './employee/staff-registration/staff-registration.component';
import { AdvisorRegistrationComponent } from './employee/advisor-registration/advisor-registration.component';
import { ReceiptTypeComponent } from './receipt-type/receipt-type.component';
import { ChitAmountComponent } from './chit-amount/chit-amount.component';
import { TRBookComponent } from './tr-book/tr-book.component';
import { CollapseComponent } from '../ui-components/collapse/collapse.component';
import { AgentRegistrationComponent } from './agent-registration/agent-registration.component';
import { AreaComponent } from './area/area.component';
import { BankComponent } from './bank/bank.component';
import { CollectionAgentComponent } from './collection-agent/collection-agent.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

const routes: Routes = [
  {
    path: '',
    component: AppsComponent,
    children: [
      {
        path: 'branch',
        component: BranchComponent
      },
      {
        path: 'bank',
        component: BankComponent
      }
      ,
      {
        path: 'area',
        component: AreaComponent
      }
      ,
      {
        path: 'agent-registration',
        component: AgentRegistrationComponent
      }
      ,
      {
        path: 'collection-agent',
        component: CollectionAgentComponent
      }
      ,
      {
        path: 'tr-book',
        component: TRBookComponent
      }
      ,
      {
        path: 'chit-amount',
        component: ChitAmountComponent
      }
      ,
      {
        path: 'employee',
        children: [
          {
            path: 'branch-manager',
            component: RelationshipManagerComponent
          },
          {
            path: 'relationship-manager',
            component: RelationshipManagerComponent
          },
          {
            path: 'staff-registration',
            component: StaffRegistrationComponent
          },
          {
            path: 'advisor-registration',
            component: AdvisorRegistrationComponent
          }
        ]
      },
      {
        path: 'receipt-type',
        component: ReceiptTypeComponent
      }
    ]
  }
]

@NgModule({
  declarations: [
    AppsComponent,
    BranchComponent,
    BankComponent,
    AreaComponent,
    AgentRegistrationComponent,
    TRBookComponent,
    ChitAmountComponent,
    BranchComponent,
    RelationshipManagerComponent,
    StaffRegistrationComponent,
    AdvisorRegistrationComponent,
    ReceiptTypeComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    FullCalendarModule, // import the FullCalendar module! will make the FullCalendar component available
    PerfectScrollbarModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbNavModule,
    NgbCollapseModule,
    NgSelectModule,
    SimplemdeModule.forRoot({
      provide: SIMPLEMDE_CONFIG,
      useValue: {}
    })
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class AppsModule { }

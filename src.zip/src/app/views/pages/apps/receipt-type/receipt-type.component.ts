import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataTable } from "simple-datatables";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-receipt-type',
  templateUrl: './receipt-type.component.html',
  styleUrls: ['./receipt-type.component.scss']
})
export class ReceiptTypeComponent  implements OnInit {

  constructor(private modalService: NgbModal) { }
  basicModalCloseResult: string = '';

  ngOnInit(): void {
    const dataTable = new DataTable("#dataTableExample11");
  }

  openBasicModal(content){
    this.modalService.open(content, {}).result.then((result) => {
      this.basicModalCloseResult = "Modal closed" + result
    }).catch((res) => {});
  }
}
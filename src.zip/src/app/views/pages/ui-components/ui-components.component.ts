import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-components',
  templateUrl: './ui-components.component.html',
  styleUrls: []
})
export class UiComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
